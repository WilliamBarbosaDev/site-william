1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"uLei3OalvmOn2CWDcLDa4"}
