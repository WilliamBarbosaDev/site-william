exports.id=7774,exports.ids=[7774],exports.modules={40498:(a,b,c)=>{"use strict";c.d(b,{L:()=>p});var d=c(76760),e=c.n(d),f=c(73024),g=c.n(f);let h=null;function i(){if(h)return h;let a=e().join(process.cwd(),"data");g().existsSync(a)||g().mkdirSync(a,{recursive:!0});let b=e().join(a,"site.db");try{return(h=new(c(87550))(b)).pragma("journal_mode = DELETE"),h.pragma("foreign_keys = ON"),h}catch(a){throw console.error("Erro ao inicializar conex\xe3o better-sqlite3:",a),a}}var j=c(44505);let k=[{id:"crm-ia",name:"Sistema de CRM Personalizado com IA Integrada",category:"IA & Sistemas",shortDescription:"Centraliza\xe7\xe3o de leads, funil de vendas e hist\xf3rico de atendimento com insights inteligentes.",detailedBenefit:"Elimina a perda de oportunidades comerciais, distribui leads automaticamente e sugere as melhores abordagens de fechamento atrav\xe9s de IA.",expectedImpact:"Aumento de at\xe9 40% na taxa de convers\xe3o e zero leads esquecidos no processo."},{id:"agendamento-ia",name:"Sistema de Agendamento Inteligente com IA",category:"IA & Sistemas",shortDescription:"Agendamentos autom\xe1ticos com confirma\xe7\xe3o, reagendamento e sincroniza\xe7\xe3o com calend\xe1rios.",detailedBenefit:"O cliente escolhe o melhor hor\xe1rio diretamente pelo WhatsApp ou web, a IA valida disponibilidade e envia lembretes para evitar no-show.",expectedImpact:"Redu\xe7\xe3o dr\xe1stica de aus\xeancias e economia de horas da equipe em troca de mensagens manuais."},{id:"sdr-ia",name:"Agente SDR IA e Follow-up de Atendimento",category:"IA & Sistemas",shortDescription:"Atendimento imediato 24/7 com qualifica\xe7\xe3o ativa de oportunidades e nutri\xe7\xe3o de leads.",detailedBenefit:"A IA inicia a conversa em menos de 1 minuto, identifica o perfil do comprador, responde d\xfavidas do neg\xf3cio e agenda a reuni\xe3o com o vendedor.",expectedImpact:"Resposta instant\xe2nea para 100% dos contatos gerando mais reuni\xf5es comerciais qualificadas."},{id:"multicanal-ia",name:"Sistema de Gest\xe3o Multicanal (WhatsApp, Instagram e Messenger)",category:"IA & Sistemas",shortDescription:"Central \xfanica para m\xfaltiplos atendentes operando em um s\xf3 n\xfamero com automa\xe7\xf5es.",detailedBenefit:"Organiza todo o fluxo de mensagens de redes sociais em uma fila estruturada, com relat\xf3rios de performance e supervis\xe3o em tempo real.",expectedImpact:"Centraliza\xe7\xe3o do atendimento, hist\xf3rico seguro dos clientes e controle da opera\xe7\xe3o."},{id:"financeiro-ia",name:"Sistema Financeiro Empresarial com IA Integrada",category:"IA & Sistemas",shortDescription:"Controle de receitas, despesas, fluxo de caixa e relat\xf3rios preditivos inteligentes.",detailedBenefit:"Visualiza\xe7\xe3o clara da sa\xfade financeira da empresa, alertas de vencimentos e proje\xe7\xf5es geradas por intelig\xeancia artificial.",expectedImpact:"Previsibilidade or\xe7ament\xe1ria e decis\xf5es de neg\xf3cios baseadas em dados concretos."},{id:"central-tarefas-ia",name:"Central de Tarefas e Gest\xe3o de Fluxos com IA",category:"Opera\xe7\xe3o & Processos",shortDescription:"Gerenciamento automatizado de fluxos de trabalho e distribui\xe7\xe3o de demandas operacionais.",detailedBenefit:"Integra diferentes ferramentas da empresa, automatiza a passagem de bast\xe3o entre setores e monitora prazos de execu\xe7\xe3o.",expectedImpact:"Elimina\xe7\xe3o de gargalos internos e ganho substancial de produtividade na equipe."},{id:"site-institucional",name:"Site Institucional de Alta Autoridade",category:"Web & Presen\xe7a",shortDescription:"Posicionamento digital de excel\xeancia focado em credibilidade, seguran\xe7a e transmiss\xe3o de valor.",detailedBenefit:"Projetado com base em princ\xedpios editoriais modernos, velocidade extrema e clareza de mensagem para neg\xf3cios consolidados.",expectedImpact:"Eleva\xe7\xe3o imediata do valor percebido da empresa e seguran\xe7a total para clientes exigentes."},{id:"landing-page",name:"Landing Page Estrat\xe9gica de Alta Convers\xe3o",category:"Web & Presen\xe7a",shortDescription:"Estrutura focada exclusivamente em transformar visitantes e an\xfancios em clientes pagantes.",detailedBenefit:"Copywriting persuasivo, arquitetura de informa\xe7\xe3o cir\xfargica e design minimalista sem atritos para capta\xe7\xe3o de leads ou vendas.",expectedImpact:"Redu\xe7\xe3o do custo por lead (CPL) e maximiza\xe7\xe3o do retorno sobre investimento em an\xfancios."},{id:"sistema-personalizado",name:"Desenvolvimento de Sistema Sob Medida & Consultoria Estrat\xe9gica",category:"Personalizado",shortDescription:"Arquitetura customizada para regras espec\xedficas de neg\xf3cio, integra\xe7\xf5es complexas e IA dedicada.",detailedBenefit:"Constru\xeddo do zero para resolver exatamente a din\xe2mica \xfanica da sua organiza\xe7\xe3o, integrando seus sistemas legados ou ERPs.",expectedImpact:"Diferencia\xe7\xe3o competitiva absoluta e controle total sobre a tecnologia da sua empresa.",isCustomOnly:!0}];var l=c(34013),m=c(77598);async function n(){let a=i();if(!a.prepare("SELECT id FROM admin_users WHERE email = ?").get("admin@williambdesigner.com.br")){let b=await l.Ay.hash(process.env.ADMIN_PASSWORD||"admin123456",10),c=(0,m.randomUUID)(),d=new Date().toISOString();a.prepare(`
      INSERT OR IGNORE INTO admin_users (id, name, email, password_hash, role, created_at)
      VALUES (?, ?, ?, ?, 'ADMIN', ?)
    `).run(c,"William Barbosa","admin@williambdesigner.com.br",b,d),console.log("✓ Usu\xe1rio administrador inicial pronto: admin@williambdesigner.com.br")}if(0===a.prepare("SELECT COUNT(*) as count FROM site_settings").get().count){let b=new Date().toISOString(),c=[{key:"site_name",value:"William Barbosa | Estrat\xe9gia, Web & IA",category:"general"},{key:"site_headline",value:"Estrat\xe9gia, Web & IA para Empresas que Querem Liderar",category:"general"},{key:"company_name",value:"William Barbosa",category:"general"},{key:"phone",value:j.PI.phone||"5592982824592",category:"contact"},{key:"whatsapp",value:j.PI.phone||"5592982824592",category:"contact"},{key:"email",value:j.PI.email||"contato@williambdesigner.com.br",category:"contact"},{key:"location",value:j.PI.location||"Manaus — Amazonas",category:"contact"},{key:"service_area",value:j.PI.serviceArea||"Atendimento para todo o Brasil",category:"contact"},{key:"instagram",value:j.PI.socials.instagram,category:"social"},{key:"linkedin",value:j.PI.socials.linkedin,category:"social"},{key:"behance",value:j.PI.socials.behance,category:"social"},{key:"default_cta_text",value:"Iniciar Diagn\xf3stico Estrat\xe9gico",category:"cta"},{key:"default_cta_url",value:"/diagnostico",category:"cta"},{key:"seo_title",value:"William Barbosa | Estrat\xe9gia, Web & IA para Neg\xf3cios",category:"seo"},{key:"seo_description",value:"Desenvolvimento de sites estrat\xe9gicos de alta convers\xe3o e sistemas inteligentes com IA que automatizam e aceleram empresas.",category:"seo"},{key:"seo_keywords",value:"estrat\xe9gia digital, landing pages, intelig\xeancia artificial, automa\xe7\xe3o empresarial, manaus, s\xe3o paulo",category:"seo"},{key:"footer_bio",value:"Designer Estrat\xe9gico & Desenvolvedor de Solu\xe7\xf5es com IA. Transformando desafios complexos em produtos digitais de alta convers\xe3o.",category:"footer"}],d=a.prepare("INSERT INTO site_settings (key, value, category, updated_at) VALUES (?, ?, ?, ?)");for(let a of c)d.run(a.key,a.value,a.category,b);console.log("✓ Configura\xe7\xf5es do site semeadas.")}if(0===a.prepare("SELECT COUNT(*) as count FROM page_sections").get().count){let b=new Date().toISOString(),c=[{page_slug:"home",section_key:"hero",title:"Estrat\xe9gia, Web & IA para Neg\xf3cios de Alto Padr\xe3o",subtitle:"DESIGN ESTRAT\xc9GICO & ENGENHARIA DE INTELIG\xcaNCIA ARTIFICIAL",description:"Transformamos a presen\xe7a digital da sua empresa com design editorial de alto n\xedvel, arquitetura de alta convers\xe3o e agentes aut\xf4nomos de IA que reduzem custos operacionais.",cta_text:"Iniciar Diagn\xf3stico com IA",cta_url:"/diagnostico",image_url:"/assets/hero-mockup.png",content_json:JSON.stringify({badge:"Dispon\xedvel para novos projetos estrat\xe9gicos",secondary_cta_text:"Ver Portf\xf3lio",secondary_cta_url:"/projetos"}),display_order:1},{page_slug:"home",section_key:"solutions",title:"Solu\xe7\xf5es Digitais Sob Medida",subtitle:"CAPACIDADES ESTRAT\xc9GICAS",description:"Estruturamos ecossistemas completos para elevar a autoridade da sua marca e gerar mais receita previs\xedvel.",cta_text:"Consultar Solu\xe7\xe3o",cta_url:"/diagnostico",display_order:2},{page_slug:"home",section_key:"projects",title:"Portf\xf3lio Selecionado & Cases",subtitle:"RESULTADOS REAIS",description:"Uma sele\xe7\xe3o de sites, landing pages de alta convers\xe3o e sistemas com IA projetados com m\xe1xima precis\xe3o est\xe9tica e t\xe9cnica.",cta_text:"Explorar Todos os Projetos",cta_url:"/projetos",display_order:3},{page_slug:"home",section_key:"cta_banner",title:"Pronto para transformar sua presen\xe7a digital?",subtitle:"VAMOS CONVERSAR",description:"Descubra qual solu\xe7\xe3o digital ou sistema com intelig\xeancia artificial \xe9 ideal para os gargalos atuais da sua empresa.",cta_text:"Falar com William Barbosa",cta_url:`https://wa.me/5592982824592?text=${encodeURIComponent("Ol\xe1 William, gostaria de conversar sobre um projeto digital para minha empresa.")}`,display_order:4}],d=a.prepare(`
      INSERT INTO page_sections (id, page_slug, section_key, title, subtitle, description, cta_text, cta_url, image_url, content_json, is_active, display_order, status, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'PUBLISHED', ?)
    `);for(let a of c)d.run((0,m.randomUUID)(),a.page_slug,a.section_key,a.title,a.subtitle,a.description,a.cta_text,a.cta_url,a.image_url||null,a.content_json||null,a.display_order,b);console.log("✓ Se\xe7\xf5es do CMS semeadas.")}if(0===a.prepare("SELECT COUNT(*) as count FROM services").get().count){let b=new Date().toISOString(),c=a.prepare(`
      INSERT INTO services (id, slug, name, title, short_description, full_description, icon, benefits_json, problems_json, cta_text, cta_url, display_order, is_active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);k.forEach((a,d)=>{c.run((0,m.randomUUID)(),a.id,a.name,a.name,a.shortDescription,a.detailedBenefit,"Sparkles",JSON.stringify([a.expectedImpact]),JSON.stringify([a.category]),"Solicitar Or\xe7amento",`https://wa.me/5592982824592?text=${encodeURIComponent(`Ol\xe1! Gostaria de saber mais sobre ${a.name}.`)}`,d+1,b,b)}),console.log("✓ Servi\xe7os semeados no banco.")}if(0===a.prepare("SELECT COUNT(*) as count FROM projects").get().count){let b=new Date().toISOString(),c=a.prepare(`
      INSERT INTO projects (id, slug, title, category, services, description, cover_image, whatsapp_message, is_featured, display_order, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PUBLISHED', ?, ?)
    `);j.jA.forEach((a,d)=>{let e=a.title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)+/g,"");c.run((0,m.randomUUID)(),`${e}-${d+1}`,a.title,a.category,a.services,a.description,a.image,a.whatsappMessage,+(d<6),d+1,b,b)}),console.log("✓ Projetos semeados no banco.")}if(0===a.prepare("SELECT COUNT(*) as count FROM ai_providers").get().count){let b=new Date().toISOString(),c=(0,m.randomUUID)(),d=(0,m.randomUUID)(),e=(0,m.randomUUID)(),f=a.prepare(`
      INSERT INTO ai_providers (id, name, provider_type, base_url, is_active, priority, status, created_at)
      VALUES (?, ?, ?, ?, 1, ?, 'READY', ?)
    `);f.run(c,"Google Gemini","gemini","https://generativelanguage.googleapis.com/v1beta",1,b),f.run(d,"OpenAI","openai","https://api.openai.com/v1",2,b),f.run(e,"Anthropic Claude","anthropic","https://api.anthropic.com/v1",3,b);let g=a.prepare(`
      INSERT INTO ai_models (id, provider_id, name, model_id, category, is_active, priority, max_tokens, notes, created_at)
      VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
    `),h=(0,m.randomUUID)();g.run(h,c,"Gemini 2.5 Flash","gemini-2.5-flash","FAST",1,8192,"Ideal para respostas ultra-r\xe1pidas e diagn\xf3sticos em tempo real",b),g.run((0,m.randomUUID)(),c,"Gemini 2.5 Pro","gemini-2.5-pro","REASONING",2,8192,"Modelo anal\xedtico para gera\xe7\xe3o aprofundada de artigos e relat\xf3rios",b);let i=(0,m.randomUUID)();g.run(i,d,"GPT-4o","gpt-4o","GENERAL",1,4096,"Modelo multimodal topo de linha da OpenAI",b),g.run((0,m.randomUUID)(),d,"GPT-4o Mini","gpt-4o-mini","FAST",2,4096,"R\xe1pido e econ\xf4mico para tarefas de suporte",b);let j=(0,m.randomUUID)();g.run(j,e,"Claude 3.5 Sonnet","claude-3-5-sonnet-20241022","REASONING",1,8192,"Excelente para escrita de artigos e reda\xe7\xe3o publicit\xe1ria",b);let k=a.prepare(`
      INSERT INTO ai_routes (id, task_name, primary_provider_id, primary_model_id, fallback1_provider_id, fallback1_model_id, fallback2_provider_id, fallback2_model_id, is_active, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);for(let a of["CHAT","DIAGNOSTIC_INTERVIEW","BUSINESS_ANALYSIS","FINAL_DIAGNOSIS","BLOG_IDEATION","BLOG_WRITING","BLOG_SEO","CONTENT_REWRITE","SERVICE_RECOMMENDATION"])k.run((0,m.randomUUID)(),a,c,h,d,i,e,j,b);console.log("✓ Provedores, Modelos e Rotas de IA semeados.")}if(0===a.prepare("SELECT COUNT(*) as count FROM ai_prompts").get().count){let b=new Date().toISOString(),c=[{identifier:"DIAGNOSTIC_AGENT",name:"Agente de Diagn\xf3stico e Consultoria Estrat\xe9gica",template:`Voc\xea \xe9 o Agente Consultor e Assistente Estrat\xe9gico oficial de William Barbosa (Especialista em Estrat\xe9gia, Web Design de Alto Padr\xe3o e Automa\xe7\xe3o com Intelig\xeancia Artificial).
Seu objetivo \xe9 conduzir um diagn\xf3stico consultivo refinado com o visitante, entender o est\xe1gio de sua empresa, identificar dores e recomendar a solu\xe7\xe3o perfeita dentre a grade oficial de servi\xe7os ou agendar uma reuni\xe3o estrat\xe9gica com William Barbosa quando a demanda for sob medida.`},{identifier:"BLOG_WRITER",name:"Redator Especialista de Artigos para Blog",template:`Voc\xea \xe9 o estrategista de conte\xfado e redator executivo de William Barbosa.
Escreva um artigo de blog com profundidade, embasamento t\xe9cnico, tom profissional, persuasivo e altamente acess\xedvel.
Estruture o texto com T\xedtulo instigante, introdu\xe7\xe3o com gancho forte, se\xe7\xf5es bem divididas (H2 e H3), listas pr\xe1ticas, insights acion\xe1veis e um Call to Action (CTA) direcionado para realiza\xe7\xe3o de diagn\xf3stico ou contato comercial.`},{identifier:"BLOG_SEO",name:"Otimizador de SEO para Conte\xfado",template:`Voc\xea \xe9 um especialista em SEO t\xe9cnico e copywriting para buscadores.
Dada uma pauta ou artigo, gere:
1. Meta Title (m\xe1ximo 60 caracteres)
2. Meta Description (m\xe1ximo 155 caracteres)
3. 5 a 10 Palavras-chave sem\xe2nticas
4. Sugest\xe3o de Slug amig\xe1vel
5. Resumo executivo para OpenGraph.`}],d=a.prepare(`
      INSERT INTO ai_prompts (id, identifier, name, prompt_template, version, is_active, updated_at)
      VALUES (?, ?, ?, ?, 1, 1, ?)
    `);for(let a of c)d.run((0,m.randomUUID)(),a.identifier,a.name,a.template,b);console.log("✓ Prompts de IA semeados.")}if(0===a.prepare("SELECT COUNT(*) as count FROM ai_agents").get().count){let b=new Date().toISOString(),c=a.prepare(`
      INSERT INTO ai_agents (
        id, slug, name, role_title, category, description,
        system_instructions, avatar_emoji, temperature, max_tokens,
        trigger_phrases_json, is_active, display_order, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
    `);for(let a of[{slug:"william-closer-ai",name:"William Closer AI",role_title:"Consultor Comercial & Fechamento de Vendas",category:"SALES",description:"Especialista em vendas consultivas, quebra de obje\xe7\xf5es de pre\xe7o, valor percebido e fechamento no WhatsApp.",system_instructions:`Voc\xea \xe9 o William Closer AI, o Agente Consultor Comercial e de Fechamento de Vendas oficial de William Barbosa.
Seu objetivo \xe9 conduzir conversas de alto n\xedvel com empres\xe1rios e tomadores de decis\xe3o, gerando valor percebido imediato, desmistificando investimentos e conduzindo o cliente com eleg\xe2ncia para o fechamento ou agendamento direto com o William no WhatsApp: +55 (92) 98282-4592.

INFORMA\xc7\xd5ES DA EMPRESA:
- Especialista: William Barbosa (Designer Estrat\xe9gico & Desenvolvedor Fullstack com IA).
- Localiza\xe7\xe3o: Manaus - AM, atendendo todo o Brasil.
- WhatsApp: https://wa.me/5592982824592

TABELA DE PRE\xc7OS:
- Landing Page Estrat\xe9gica: a partir de R$ 2.800 (prazo ~10 dias \xfateis).
- Site Institucional de Autoridade: a partir de R$ 4.800 (prazo ~20 dias \xfateis).
- Agente SDR IA para WhatsApp: R$ 3.800 implanta\xe7\xe3o + R$ 600/m\xeas.
- Sistema de CRM com IA: a partir de R$ 6.500 (prazo ~25 dias \xfateis).
- Sistema de Agendamento com IA: a partir de R$ 3.500 (prazo ~14 dias \xfateis).
- Solu\xe7\xf5es Sob Medida: a partir de R$ 8.500.

DIRETRIZES:
- Demonstre autoridade, eleg\xe2ncia e foco em ROI.
- Sempre direcione para o WhatsApp: "Podemos alinhar os detalhes diretamente com o William no WhatsApp (92) 98282-4592."`,avatar_emoji:"\uD83D\uDCBC",temperature:.7,max_tokens:4096,triggers:["Quanto custa para fazer um site?","Qual a diferen\xe7a entre o William e uma ag\xeancia?","Preciso de mais vendas urgente, o que fazer?"],display_order:1},{slug:"sdr-qualificador",name:"SDR Qualificador de Leads",role_title:"Pr\xe9-Vendas, Triagem & Atendimento Imediato",category:"SDR",description:"Recepciona contatos, identifica o segmento, dores e urg\xeancia, preparando o lead para a proposta comercial.",system_instructions:`Voc\xea \xe9 o SDR Qualificador de Leads de William Barbosa.
Sua miss\xe3o \xe9 recepcionar clientes com extrema agilidade e cordialidade, fazendo uma triagem r\xe1pida:
1. Qual o segmento da sua empresa?
2. Qual o principal gargalo atual (site antigo, falta de leads, demora para responder no WhatsApp)?
3. Qual o momento e urg\xeancia do projeto?
Apresente a solu\xe7\xe3o ideal da esteira de servi\xe7os de William Barbosa e direcione para o WhatsApp: +55 (92) 98282-4592.`,avatar_emoji:"⚡",temperature:.6,max_tokens:2048,triggers:["Ol\xe1, gostaria de um or\xe7amento","Voc\xeas fazem landing page para m\xe9dicos?","Como funciona o atendimento por IA no WhatsApp?"],display_order:2},{slug:"suporte-atendimento",name:"Especialista de Atendimento & Suporte",role_title:"D\xfavidas Operacionais, Prazos & Metodologia",category:"SUPPORT",description:"Tira d\xfavidas de clientes e prospects sobre prazos de entrega, metodologia em 4 passos e garantia de 30 dias.",system_instructions:`Voc\xea \xe9 o Especialista de Atendimento & Suporte de William Barbosa.
Responda com clareza sobre o m\xe9todo de trabalho:
- Metodologia: 01. Entender -> 02. Estruturar -> 03. Criar (Design Figma + Next.js) -> 04. Implementar & Testar.
- Prazos: Landing Pages (~10 dias), Sites (~20 dias), Sistemas/CRM (~25 dias).
- Garantia: 30 dias de ajustes p\xf3s-entrega inclusos.
- Pagamentos: Entrada + entrega ou at\xe9 12x no cart\xe3o.
- Contato oficial: WhatsApp +55 (92) 98282-4592.`,avatar_emoji:"\uD83D\uDEE1️",temperature:.5,max_tokens:2048,triggers:["Como funciona o pagamento?","Qual o prazo de entrega?","Voc\xeas d\xe3o garantia depois que o site estiver no ar?"],display_order:3},{slug:"arquiteto-solucoes",name:"Arquiteto de Solu\xe7\xf5es & IA",role_title:"Consultor T\xe9cnico & Engenharia de Software",category:"TECHNICAL",description:"Consultoria t\xe9cnica sobre arquitetura Next.js 15, integra\xe7\xf5es de APIs, banco de dados Supabase e automa\xe7\xf5es com IA.",system_instructions:`Voc\xea \xe9 o Arquiteto de Solu\xe7\xf5es & Engenheiro de IA de William Barbosa.
Auxilie clientes com d\xfavidas t\xe9cnicas avan\xe7adas:
- Stack moderna: Next.js 15, React 19, TypeScript, Tailwind CSS, Supabase (PostgreSQL), APIs RESTful.
- Intelig\xeancia Artificial: LLMs integrados via Groq (Llama 3.3 LPU para velocidade m\xe1xima), OpenAI, Claude e Gemini com sistema de fallback em cascata.
- Seguran\xe7a: Chaves criptografadas no backend, cookies HTTP-only, prote\xe7\xe3o contra XSS e SQL Injection.`,avatar_emoji:"\uD83C\uDFD7️",temperature:.6,max_tokens:4096,triggers:["Por que usar Next.js em vez de WordPress?","Como a IA \xe9 integrada no WhatsApp?","O banco de dados \xe9 seguro?"],display_order:4},{slug:"copywriter-estrategico",name:"Copywriter Estrat\xe9gico",role_title:"Redator Executivo & Estrategista de Conte\xfado",category:"CONTENT",description:"Redige artigos, pautas para o blog, scripts de vendas e headlines persuasivas no tom de voz sofisticado da marca.",system_instructions:`Voc\xea \xe9 o Copywriter Estrat\xe9gico de William Barbosa.
Escreva conte\xfados persuasivos, elegantes e focados em ROI.
Evite clich\xeas vazios de marketing. Destaque a uni\xe3o entre design impec\xe1vel e tecnologia com Intelig\xeancia Artificial para gerar convers\xe3o real.`,avatar_emoji:"✍️",temperature:.8,max_tokens:4096,triggers:["Crie uma headline para landing page jur\xeddica","Ideia de artigo sobre IA para pequenas empresas","Roteiro de abordagem comercial"],display_order:5}])c.run((0,m.randomUUID)(),a.slug,a.name,a.role_title,a.category,a.description,a.system_instructions,a.avatar_emoji,a.temperature,a.max_tokens,JSON.stringify(a.triggers),a.display_order,b,b);console.log("✓ 5 Agentes Especializados de IA semeados com sucesso.")}try{let b=a.prepare(`
      UPDATE services
      SET price_starting_at = COALESCE(price_starting_at, ?),
          price_model = COALESCE(price_model, ?),
          price_notes = COALESCE(price_notes, ?),
          deliverables_json = COALESCE(deliverables_json, ?),
          estimated_days = COALESCE(estimated_days, ?)
      WHERE slug = ? OR id = ?
    `);b.run("R$ 2.800,00","PROJETO_UNICO","50% entrada + 50% entrega ou at\xe9 12x",JSON.stringify(["Diagn\xf3stico de oferta","Design Figma","Next.js","Garantia 30 dias"]),10,"landing-page","landing-page"),b.run("R$ 4.800,00","PROJETO_UNICO","50% entrada + 50% entrega ou at\xe9 12x",JSON.stringify(["CMS completo","SEO on-page","Design de autoridade","Next.js"]),20,"site-institucional","site-institucional"),b.run("R$ 6.500,00","PROJETO_UNICO","Parcelamento em at\xe9 3x durante o desenvolvimento",JSON.stringify(["Pipeline Kanban","Qualifica\xe7\xe3o IA","Hist\xf3rico de clientes","Dashboard"]),25,"crm-ia","crm-ia"),b.run("R$ 3.800,00","MENSAL_RECORRENTE","Implanta\xe7\xe3o parcel\xe1vel + mensalidade de R$ 600/m\xeas",JSON.stringify(["Treinamento IA","WhatsApp 24/7","Triagem de leads","Painel de m\xe9tricas"]),12,"sdr-ia","sdr-ia"),b.run("R$ 3.500,00","PROJETO_UNICO","50% entrada + 50% entrega ou at\xe9 12x",JSON.stringify(["Calend\xe1rio din\xe2mico","Lembretes WhatsApp","Sincroniza\xe7\xe3o Google Calendar"]),14,"agendamento-ia","agendamento-ia"),b.run("A partir de R$ 8.500,00","SOB_CONSULTA","Cronograma financeiro por marcos de entrega (milestones)",JSON.stringify(["Arquitetura customizada","Backend e APIs","Integra\xe7\xf5es ERP","Deploy nuvem"]),30,"sistema-personalizado","sistema-personalizado"),console.log("✓ Precifica\xe7\xe3o padr\xe3o dos servi\xe7os atualizada.")}catch(a){console.warn("Pricing update warning:",a)}}let o=!1;async function p(){let a=i();if(!o){let a=i(),b=`
    -- 1. Admin Users
    CREATE TABLE IF NOT EXISTS admin_users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'ADMIN',
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );

    -- 2. Site Settings
    CREATE TABLE IF NOT EXISTS site_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'general',
      updated_at TEXT NOT NULL
    );

    -- 3. Pages & Sections (CMS)
    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      seo_title TEXT,
      seo_description TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS page_sections (
      id TEXT PRIMARY KEY,
      page_slug TEXT NOT NULL,
      section_key TEXT NOT NULL,
      title TEXT,
      subtitle TEXT,
      description TEXT,
      cta_text TEXT,
      cta_url TEXT,
      image_url TEXT,
      content_json TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'PUBLISHED',
      updated_at TEXT NOT NULL,
      UNIQUE(page_slug, section_key)
    );

    -- 4. Services
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      title TEXT NOT NULL,
      short_description TEXT NOT NULL,
      full_description TEXT,
      image_url TEXT,
      icon TEXT,
      benefits_json TEXT,
      problems_json TEXT,
      price_starting_at TEXT,
      price_model TEXT NOT NULL DEFAULT 'PROJETO_UNICO', -- PROJETO_UNICO, MENSAL_RECORRENTE, SOB_CONSULTA, HORA_CONSULTORIA
      price_notes TEXT,
      deliverables_json TEXT,
      estimated_days INTEGER DEFAULT 15,
      cta_text TEXT,
      cta_url TEXT,
      seo_title TEXT,
      seo_description TEXT,
      display_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 5. Projects (Portfolio & Cases)
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      client TEXT,
      category TEXT NOT NULL,
      services TEXT,
      description TEXT NOT NULL,
      problem TEXT,
      solution TEXT,
      technologies_json TEXT,
      results_json TEXT,
      cover_image TEXT NOT NULL,
      images_json TEXT,
      project_url TEXT,
      whatsapp_message TEXT,
      is_featured INTEGER NOT NULL DEFAULT 0,
      display_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'PUBLISHED',
      seo_title TEXT,
      seo_description TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 6. Blog
    CREATE TABLE IF NOT EXISTS blog_categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS blog_tags (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blog_posts (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      summary TEXT,
      content TEXT NOT NULL,
      featured_image TEXT,
      category_id TEXT,
      tags_json TEXT,
      author TEXT NOT NULL DEFAULT 'William Barbosa',
      status TEXT NOT NULL DEFAULT 'DRAFT', -- DRAFT, SCHEDULED, PUBLISHED, ARCHIVED
      scheduled_at TEXT,
      published_at TEXT,
      seo_title TEXT,
      seo_description TEXT,
      seo_keywords TEXT,
      og_image TEXT,
      canonical_url TEXT,
      is_ai_generated INTEGER NOT NULL DEFAULT 0,
      ai_generation_meta TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 7. Content Ideas & Automations
    CREATE TABLE IF NOT EXISTS content_ideas (
      id TEXT PRIMARY KEY,
      topic TEXT NOT NULL,
      keyword TEXT,
      category TEXT,
      objective TEXT,
      priority TEXT NOT NULL DEFAULT 'MEDIUM', -- LOW, MEDIUM, HIGH
      status TEXT NOT NULL DEFAULT 'IDEA', -- IDEA, PLANNED, GENERATED, PUBLISHED
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS content_automations (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 0,
      frequency TEXT NOT NULL DEFAULT 'WEEKLY', -- DAILY, WEEKLY, BIWEEKLY, MONTHLY
      day_of_week TEXT DEFAULT 'MONDAY',
      time_of_day TEXT DEFAULT '09:00',
      category_id TEXT,
      themes_json TEXT,
      keywords_json TEXT,
      provider_id TEXT,
      model_id TEXT,
      prompt_id TEXT,
      auto_publish INTEGER NOT NULL DEFAULT 0,
      last_run_at TEXT,
      next_run_at TEXT,
      created_at TEXT NOT NULL
    );

    -- 8. AI Engine: Providers, Models, Routes, Prompts, Logs
    CREATE TABLE IF NOT EXISTS ai_providers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      provider_type TEXT NOT NULL, -- openai, gemini, anthropic, custom
      api_key_encrypted TEXT,
      base_url TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      priority INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'READY',
      last_used_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_models (
      id TEXT PRIMARY KEY,
      provider_id TEXT NOT NULL,
      name TEXT NOT NULL,
      model_id TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'GENERAL', -- FAST, REASONING, VISION, GENERAL
      is_active INTEGER NOT NULL DEFAULT 1,
      priority INTEGER NOT NULL DEFAULT 1,
      max_tokens INTEGER DEFAULT 4096,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_routes (
      id TEXT PRIMARY KEY,
      task_name TEXT UNIQUE NOT NULL,
      primary_provider_id TEXT,
      primary_model_id TEXT,
      fallback1_provider_id TEXT,
      fallback1_model_id TEXT,
      fallback2_provider_id TEXT,
      fallback2_model_id TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_prompts (
      id TEXT PRIMARY KEY,
      identifier TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      prompt_template TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_prompt_versions (
      id TEXT PRIMARY KEY,
      prompt_id TEXT NOT NULL,
      version INTEGER NOT NULL,
      prompt_template TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_logs (
      id TEXT PRIMARY KEY,
      task_name TEXT NOT NULL,
      provider_used TEXT,
      model_used TEXT,
      tokens_prompt INTEGER DEFAULT 0,
      tokens_completion INTEGER DEFAULT 0,
      duration_ms INTEGER DEFAULT 0,
      status TEXT NOT NULL, -- SUCCESS, FALLBACK, ERROR
      error_message TEXT,
      created_at TEXT NOT NULL
    );

    -- 8.1 AI Specialized Agents (Closer, SDR, Suporte, Custom)
    CREATE TABLE IF NOT EXISTS ai_agents (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      role_title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'CUSTOM', -- SALES, SDR, SUPPORT, TECHNICAL, CONTENT, CUSTOM
      description TEXT NOT NULL,
      system_instructions TEXT NOT NULL,
      provider_id TEXT,
      model_id TEXT,
      temperature REAL DEFAULT 0.7,
      max_tokens INTEGER DEFAULT 4096,
      avatar_emoji TEXT DEFAULT '🤖',
      trigger_phrases_json TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 9. Leads & Diagnostics
    CREATE TABLE IF NOT EXISTS leads (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      company TEXT,
      phone TEXT NOT NULL,
      email TEXT,
      source TEXT NOT NULL DEFAULT 'SITE',
      status TEXT NOT NULL DEFAULT 'NEW', -- NEW, CONTACTED, QUALIFIED, PROPOSAL, CLIENT, LOST
      diagnostic_id TEXT,
      recommended_services_json TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS diagnostics (
      id TEXT PRIMARY KEY,
      lead_id TEXT,
      client_name TEXT NOT NULL,
      company_name TEXT,
      phone TEXT NOT NULL,
      email TEXT,
      segment TEXT,
      challenge TEXT,
      current_process TEXT,
      goal TEXT,
      maturity_score INTEGER DEFAULT 0,
      is_custom_need INTEGER NOT NULL DEFAULT 0,
      recommended_solution TEXT,
      summary TEXT,
      provider_used TEXT,
      model_used TEXT,
      raw_payload_json TEXT,
      created_at TEXT NOT NULL
    );

    -- 10. Media Library
    CREATE TABLE IF NOT EXISTS media (
      id TEXT PRIMARY KEY,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      url TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    -- 11. Audit Logs
    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      details_json TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );

    -- Indexes for performance
    CREATE INDEX IF NOT EXISTS idx_page_sections_page ON page_sections(page_slug);
    CREATE INDEX IF NOT EXISTS idx_blog_posts_status ON blog_posts(status);
    CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON blog_posts(slug);
    CREATE INDEX IF NOT EXISTS idx_projects_featured ON projects(is_featured);
    CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
    CREATE INDEX IF NOT EXISTS idx_ai_logs_created ON ai_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_ai_agents_slug ON ai_agents(slug);
    CREATE INDEX IF NOT EXISTS idx_ai_agents_active ON ai_agents(is_active);
  `;a.exec(b);try{let b=a.prepare("PRAGMA table_info(services)").all().map(a=>a.name);b.includes("price_starting_at")||a.exec("ALTER TABLE services ADD COLUMN price_starting_at TEXT"),b.includes("price_model")||a.exec("ALTER TABLE services ADD COLUMN price_model TEXT NOT NULL DEFAULT 'PROJETO_UNICO'"),b.includes("price_notes")||a.exec("ALTER TABLE services ADD COLUMN price_notes TEXT"),b.includes("deliverables_json")||a.exec("ALTER TABLE services ADD COLUMN deliverables_json TEXT"),b.includes("estimated_days")||a.exec("ALTER TABLE services ADD COLUMN estimated_days INTEGER DEFAULT 15")}catch(a){console.warn("Migration warning for services table:",a)}await n(),o=!0}return a}},44505:(a,b,c)=>{"use strict";c.d(b,{PI:()=>d,jA:()=>e});let d={phone:"5592982824592",email:"contato@williambdesigner.com.br",location:"Manaus — Amazonas",serviceArea:"Atendimento para todo o Brasil",socials:{instagram:"https://instagram.com/williamb.designer",linkedin:"https://linkedin.com/in/williambarbosa",behance:"https://behance.net/williambarbosa"}},e=[{title:"VerJuris Advocacia",category:"Site Institucional",services:"Estrat\xe9gia • UX/UI • Web Design",image:"/assets/fotos_projetos/site_verjuris.png",description:"Presen\xe7a digital jur\xeddica de alta autoridade, pensada para transmitir clareza, seguran\xe7a e \xe9tica.",whatsappMessage:"Ol\xe1 William! Gostaria de um site institucional estrat\xe9gico como o da VerJuris."},{title:"CASI Imobili\xe1ria",category:"Site Corporativo",services:"Estrat\xe9gia • UX/UI • Imobili\xe1rio",image:"/assets/fotos_projetos/site_casiimobiliaria.png",description:"Plataforma para o setor imobili\xe1rio focada em neg\xf3cios de alto padr\xe3o, moradia e investimento em Manaus.",whatsappMessage:"Ol\xe1 William! Gostaria de solu\xe7\xf5es digitais para o setor imobili\xe1rio como o da CASI."},{title:"VerGroup Contabilidade",category:"Site Institucional",services:"Estrat\xe9gia • UX/UI • Contabilidade Digital",image:"/assets/fotos_projetos/site_contabilidade_vergroup.png",description:"Contabilidade sem burocracia para servi\xe7os, PJ e empresas, com estrutura focada na redu\xe7\xe3o fiscal e convers\xe3o.",whatsappMessage:"Ol\xe1 William! Gostaria de um site como o do VerGroup / VerCont\xe1bil."},{title:"AMcash Bank",category:"Plataforma Financeira",services:"Branding • UX/UI • Fintech",image:"/assets/fotos_projetos/site_amcash.png",description:"Solu\xe7\xe3o para antecipa\xe7\xe3o de receb\xedveis e fomento mercantil com posicionamento financeiro moderno.",whatsappMessage:"Ol\xe1 William! Gostaria de desenvolver uma solu\xe7\xe3o digital para minha financeira."},{title:"VerAds IA",category:"Hub Tecnol\xf3gico & IA",services:"Estrat\xe9gia • UX/UI • IA & Performance",image:"/assets/fotos_projetos/site_verads.png",description:"Hub de crescimento focado em marketing de performance e solu\xe7\xf5es digitais impulsionadas por Intelig\xeancia Artificial.",whatsappMessage:"Ol\xe1 William! Gostaria de uma presen\xe7a digital com foco em IA e escala."},{title:"Web Saudi Certificadora",category:"E-commerce & Servi\xe7os",services:"UX/UI • E-commerce • Landing Page",image:"/assets/fotos_projetos/site_certificadora.png",description:"Plataforma para aquisi\xe7\xe3o \xe1gil e segura de certificados digitais e-CPF e e-CNPJ para pessoas e empresas.",whatsappMessage:"Ol\xe1 William! Gostaria de uma plataforma \xe1gil de venda de servi\xe7os e certificados."},{title:"AG Projetos & Or\xe7amentos",category:"Landing Page / Arquitetura",services:"Estrat\xe9gia • Landing Page • UX/UI",image:"/assets/fotos_projetos/site_arquiteta.png",description:"Apresenta\xe7\xe3o t\xe9cnica e comercial para or\xe7amentos e projetos arquitet\xf4nicos residenciais e corporativos.",whatsappMessage:"Ol\xe1 William! Gostaria de uma landing page para or\xe7amentos de arquitetura e engenharia."},{title:"Master's Instala\xe7\xf5es & Engenharia",category:"Site Corporativo",services:"Estrat\xe9gia • UX/UI • Engenharia Industrial",image:"/assets/fotos_projetos/site_materengenharia.png",description:"Mais de 20 anos no mercado com servi\xe7os especializados de instala\xe7\xf5es el\xe9tricas e hidr\xe1ulicas industriais.",whatsappMessage:"Ol\xe1 William! Gostaria de um site corporativo para minha empresa de engenharia/instala\xe7\xf5es."},{title:"Nova Igreja Batista Cidade de Deus",category:"Portal Institucional",services:"UX/UI • Web Design • Comunidade",image:"/assets/fotos_projetos/site_igreja.png",description:"Portal institucional e comunit\xe1rio com organiza\xe7\xe3o de minist\xe9rios, eventos, transmiss\xf5es e programa\xe7\xf5es.",whatsappMessage:"Ol\xe1 William! Gostaria de desenvolver um portal para minha institui\xe7\xe3o."},{title:"VerAcademy — Hub Educacional",category:"Portal & Plataforma",services:"UX/UI • E-learning • IA & Gest\xe3o",image:"/assets/fotos_projetos/site_portalcadaemico.png",description:"Hub educacional para neg\xf3cios que capacita empresas, l\xedderes e equipes em Intelig\xeancia Artificial e gest\xe3o.",whatsappMessage:"Ol\xe1 William! Gostaria de um hub educacional e plataforma de cursos."},{title:"Anderson Lincoln Vital — Direito M\xe9dico",category:"Landing Page / Jur\xeddico",services:"Copywriting • Landing Page • High-Ticket",image:"/assets/fotos_projetos/lp_advogado.png",description:"Workshop e adequa\xe7\xe3o em privacidade e prote\xe7\xe3o de dados (LGPD) para cl\xednicas e consult\xf3rios m\xe9dicos.",whatsappMessage:"Ol\xe1 William! Gostaria de uma landing page para workshop/advocacia."},{title:"Desafio dos An\xfancios Online",category:"P\xe1gina de Vendas & Captura",services:"Copywriting • Landing Page • Performance",image:"/assets/fotos_projetos/lp_evento_anuncios.png",description:"P\xe1gina de alta convers\xe3o para captura de leads e lan\xe7amento de treinamento em gest\xe3o de tr\xe1fego pago.",whatsappMessage:"Ol\xe1 William! Quero estruturar uma p\xe1gina de captura para meu lan\xe7amento."},{title:"IPEMED / Afya Educa\xe7\xe3o M\xe9dica",category:"Landing Page / Sa\xfade",services:"Estrat\xe9gia • UX/UI • Educa\xe7\xe3o M\xe9dica",image:"/assets/fotos_projetos/lp_medial.png",description:"P\xe1gina de capta\xe7\xe3o para p\xf3s-gradua\xe7\xe3o m\xe9dica e workshops exclusivos para profissionais da sa\xfade.",whatsappMessage:"Ol\xe1 William! Gostaria de uma p\xe1gina de capta\xe7\xe3o para o setor de sa\xfade."},{title:"Treinamento Gar\xe7om Vendedor",category:"P\xe1gina de Vendas",services:"Copy • UX/UI • Convers\xe3o",image:"/assets/fotos_projetos/garcom_vendedor_lp.png",description:"M\xe9todo pr\xe1tico de treinamento para aumentar o faturamento de restaurantes e bares em at\xe9 30%.",whatsappMessage:"Ol\xe1 William! Quero uma p\xe1gina de vendas para meu treinamento."},{title:"Paloma Maia Beauty",category:"Landing Page / Est\xe9tica",services:"Branding • UX/UI • Cat\xe1logo VIP",image:"/assets/fotos_projetos/lp_esteticista.png",description:"Apresenta\xe7\xe3o de cat\xe1logo oficial de servi\xe7os de est\xe9tica avan\xe7ada e agendamento VIP.",whatsappMessage:"Ol\xe1 William! Gostaria de uma p\xe1gina exclusiva para servi\xe7os de est\xe9tica e beleza."},{title:"Face Doctor — Est\xe9tica Premium",category:"Landing Page / Est\xe9tica",services:"Copy • UX/UI • Agendamentos",image:"/assets/fotos_projetos/lp_estetica.png",description:"Cl\xednica de est\xe9tica facial e corporal com foco em rejuvenescimento e capta\xe7\xe3o de procedimentos.",whatsappMessage:"Ol\xe1 William! Gostaria de uma landing page para capta\xe7\xe3o de agendamentos em cl\xednica."},{title:"Masterclass Full Stack",category:"P\xe1gina de Vendas & Captura",services:"Copywriting • Landing Page • Tech",image:"/assets/fotos_projetos/lp_cursos.png",description:"P\xe1gina de captura e inscri\xe7\xe3o para masterclass ao vivo de programa\xe7\xe3o e carreira em tecnologia.",whatsappMessage:"Ol\xe1 William! Quero uma p\xe1gina de captura para evento de tecnologia."},{title:"A\xe7a\xed do Jota",category:"Site & Delivery",services:"UX/UI • Card\xe1pio Digital • Convers\xe3o",image:"/assets/fotos_projetos/site_acai.png",description:"Site comercial e card\xe1pio interativo de combos promocionais e delivery para franquia de a\xe7a\xed.",whatsappMessage:"Ol\xe1 William! Gostaria de um site comercial/delivery para meu neg\xf3cio de alimenta\xe7\xe3o."},{title:"Cafena Cafeteria",category:"Site Institucional",services:"Branding • UX/UI • Gastronomia",image:"/assets/fotos_projetos/site_cafeteria.png",description:"Experi\xeancia digital sofisticada para cafeteria de gr\xe3os especiais com card\xe1pio e avalia\xe7\xf5es.",whatsappMessage:"Ol\xe1 William! Gostaria de um site institucional para minha cafeteria/restaurante."},{title:"Restaurante Sabor Brasileiro",category:"Site Institucional",services:"UX/UI • Web Design • Delivery",image:"/assets/fotos_projetos/site_restaurante.png",description:"Presen\xe7a digital para restaurante tradicional com card\xe1pio de pratos, sobremesas e pedidos r\xe1pidos.",whatsappMessage:"Ol\xe1 William! Gostaria de um site para meu restaurante."},{title:"Marmitas Fit da Lili",category:"E-commerce",services:"UX/UI • E-commerce • Pedidos",image:"/assets/fotos_projetos/site_ecommerce_marmitas.png",description:"E-commerce de marmitas saud\xe1veis fit e low carb com cat\xe1logo de combos e pedidos automatizados.",whatsappMessage:"Ol\xe1 William! Gostaria de um e-commerce de marmitas e alimenta\xe7\xe3o saud\xe1vel."},{title:"Notecell Celular",category:"E-commerce",services:"UX/UI • E-commerce • Varejo Tech",image:"/assets/fotos_projetos/ecommerce_cellular.png",description:"Loja virtual completa para venda de smartphones, acess\xf3rios e assist\xeancia t\xe9cnica com entrega r\xe1pida.",whatsappMessage:"Ol\xe1 William! Gostaria de uma loja virtual para venda de eletr\xf4nicos/celulares."},{title:"Farmave Manipula\xe7\xe3o",category:"E-commerce",services:"UX/UI • E-commerce • Or\xe7amentos",image:"/assets/fotos_projetos/ecommerce_farmacia.png",description:"E-commerce e capta\xe7\xe3o de receitas para farm\xe1cia de manipula\xe7\xe3o com linha de skincare e fitoter\xe1picos.",whatsappMessage:"Ol\xe1 William! Gostaria de uma plataforma digital para minha farm\xe1cia/e-commerce."},{title:"Comercial CDA Atacado",category:"E-commerce",services:"UX/UI • E-commerce B2B • Cat\xe1logo",image:"/assets/fotos_projetos/ecommerce_comercialcda.png",description:"Distribui\xe7\xe3o e venda atacadista de produtos exclusivos com cat\xe1logo de pedidos e or\xe7amentos.",whatsappMessage:"Ol\xe1 William! Gostaria de uma plataforma B2B/atacadista para minha distribuidora."},{title:"Guto's Tour Viagens",category:"Site Corporativo",services:"UX/UI • Web Design • C\xe2mbio",image:"/assets/fotos_projetos/site_tour.png",description:"Ag\xeancia de viagens completa com pacotes internacionais para Europa, cruzeiros de luxo e c\xe2mbio de moedas.",whatsappMessage:"Ol\xe1 William! Gostaria de um site corporativo para minha ag\xeancia de turismo."},{title:"William Barbosa Studio",category:"Site Institucional",services:"Estrat\xe9gia • Design • Tecnologia",image:"/assets/fotos_projetos/site_agenciamkt.png",description:"Ag\xeancia de solu\xe7\xf5es inteligentes: da estrat\xe9gia ao desenvolvimento de inova\xe7\xe3o sob medida para neg\xf3cios.",whatsappMessage:"Ol\xe1 William! Gostaria de conversar sobre um projeto com seu est\xfadio."},{title:"Lan\xe7amento Marketing Digital",category:"Landing Page / Vendas",services:"Copywriting • UX/UI • Tr\xe1fego",image:"/assets/fotos_projetos/lp_mktdigital.png",description:"Estrutura de alta convers\xe3o para mentorias e produtos digitais de marketing e escala de vendas.",whatsappMessage:"Ol\xe1 William! Quero estruturar uma landing page de vendas para meu produto digital."}]},78335:()=>{},96487:()=>{}};