"use strict";exports.id=9442,exports.ids=[9442],exports.modules={1734:(a,b,c)=>{c.d(b,{AS:()=>h,N7:()=>i,QL:()=>o,Yv:()=>f,_c:()=>j,gg:()=>m,pD:()=>l,tY:()=>k,ys:()=>n});var d=c(40498),e=c(77598);function f(a){return a.toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)+/g,"")}function g(a){return a?a.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,"").replace(/on\w+="[^"]*"/gi,"").replace(/javascript:[^"']*/gi,""):""}async function h(a=10){return(await (0,d.L)()).prepare(`
    SELECT p.*, c.name as category_name
    FROM blog_posts p
    LEFT JOIN blog_categories c ON p.category_id = c.id
    WHERE p.status = 'PUBLISHED'
    ORDER BY p.published_at DESC, p.created_at DESC
    LIMIT ?
  `).all(a)}async function i(a){return(await (0,d.L)()).prepare(`
    SELECT p.*, c.name as category_name
    FROM blog_posts p
    LEFT JOIN blog_categories c ON p.category_id = c.id
    WHERE p.slug = ? AND p.status = 'PUBLISHED'
  `).get(a)||null}async function j(){return(await (0,d.L)()).prepare(`
    SELECT p.*, c.name as category_name
    FROM blog_posts p
    LEFT JOIN blog_categories c ON p.category_id = c.id
    ORDER BY p.created_at DESC
  `).all()}async function k(a){return(await (0,d.L)()).prepare(`
    SELECT p.*, c.name as category_name
    FROM blog_posts p
    LEFT JOIN blog_categories c ON p.category_id = c.id
    WHERE p.id = ?
  `).get(a)||null}async function l(a){let b=await (0,d.L)(),c=new Date().toISOString(),h=(0,e.randomUUID)(),i=a.slug?f(a.slug):f(a.title||"post");b.prepare("SELECT id FROM blog_posts WHERE slug = ?").get(i)&&(i=`${i}-${Date.now().toString().slice(-4)}`);let j=a.status||"DRAFT",l="PUBLISHED"===j?a.published_at||c:null;return b.prepare(`
    INSERT INTO blog_posts (
      id, slug, title, summary, content, featured_image, category_id,
      tags_json, author, status, scheduled_at, published_at,
      seo_title, seo_description, seo_keywords, og_image, canonical_url,
      is_ai_generated, ai_generation_meta, created_at, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?, ?
    )
  `).run(h,i,a.title||"Sem t\xedtulo",a.summary||"",g(a.content||""),a.featured_image||null,a.category_id||null,a.tags_json||"[]",a.author||"William Barbosa",j,a.scheduled_at||null,l,a.seo_title||a.title||"",a.seo_description||a.summary||"",a.seo_keywords||"",a.og_image||a.featured_image||null,a.canonical_url||null,+!!a.is_ai_generated,a.ai_generation_meta||null,c,c),await k(h)}async function m(a,b){let c=await (0,d.L)(),e=new Date().toISOString(),h=b.slug?f(b.slug):void 0;h&&c.prepare("SELECT id FROM blog_posts WHERE slug = ? AND id != ?").get(h,a)&&(h=`${h}-${Date.now().toString().slice(-4)}`);let i=b.published_at;if("PUBLISHED"===b.status&&!i){let b=c.prepare("SELECT published_at FROM blog_posts WHERE id = ?").get(a);i=b?.published_at||e}return c.prepare(`
    UPDATE blog_posts
    SET title = COALESCE(?, title),
        slug = COALESCE(?, slug),
        summary = COALESCE(?, summary),
        content = COALESCE(?, content),
        featured_image = COALESCE(?, featured_image),
        category_id = COALESCE(?, category_id),
        tags_json = COALESCE(?, tags_json),
        author = COALESCE(?, author),
        status = COALESCE(?, status),
        scheduled_at = COALESCE(?, scheduled_at),
        published_at = COALESCE(?, published_at),
        seo_title = COALESCE(?, seo_title),
        seo_description = COALESCE(?, seo_description),
        seo_keywords = COALESCE(?, seo_keywords),
        og_image = COALESCE(?, og_image),
        canonical_url = COALESCE(?, canonical_url),
        updated_at = ?
    WHERE id = ?
  `).run(b.title||null,h||null,b.summary||null,b.content?g(b.content):null,b.featured_image||null,b.category_id||null,b.tags_json||null,b.author||null,b.status||null,b.scheduled_at||null,i||null,b.seo_title||null,b.seo_description||null,b.seo_keywords||null,b.og_image||null,b.canonical_url||null,e,a),await k(a)}async function n(a){return(await (0,d.L)()).prepare("DELETE FROM blog_posts WHERE id = ?").run(a).changes>0}async function o(a){let b=await k(a);return b?l({title:`${b.title} (C\xf3pia)`,summary:b.summary,content:b.content,featured_image:b.featured_image,category_id:b.category_id,tags_json:b.tags_json,author:b.author,status:"DRAFT",seo_title:b.seo_title,seo_description:b.seo_description,seo_keywords:b.seo_keywords,is_ai_generated:b.is_ai_generated}):null}},19225:(a,b,c)=>{a.exports=c(44870)},35012:(a,b,c)=>{c.d(b,{Q7:()=>k,aN:()=>m,dK:()=>n,z4:()=>j});var d=c(8292),e=c(17509),f=c(65573),g=c(23211),h=c(40498);let i=new TextEncoder().encode(process.env.ADMIN_JWT_SECRET||"william-barbosa-admin-super-secret-key-2026-secure"),j="admin_session";async function k(a){return new d.P({...a}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(i)}async function l(a){try{let{payload:b}=await (0,e.V)(a,i);return{id:b.id,name:b.name,email:b.email,role:b.role}}catch{return null}}async function m(){try{let a=(await (0,f.UL)()).get(j);if(!a||!a.value)return null;let b=await l(a.value);if(!b)return null;let c=(await (0,h.L)()).prepare("SELECT id, name, email, role FROM admin_users WHERE id = ?").get(b.id);if(!c||"ADMIN"!==c.role)return null;return{id:c.id,name:c.name,email:c.email,role:c.role}}catch{return null}}async function n(a){let b;if(a&&!(b=a.cookies.get(j)?.value)){let c=a.headers.get("authorization");c&&c.startsWith("Bearer ")&&(b=c.substring(7))}if(!b){let a=await (0,f.UL)();b=a.get(j)?.value}if(!b)return g.NextResponse.json({success:!1,message:"Acesso n\xe3o autorizado. Fa\xe7a login como administrador."},{status:401});let c=await l(b);if(!c)return g.NextResponse.json({success:!1,message:"Sess\xe3o inv\xe1lida ou expirada."},{status:401});let d=(await (0,h.L)()).prepare("SELECT id, name, email, role FROM admin_users WHERE id = ?").get(c.id);return d&&"ADMIN"===d.role?{user:{id:d.id,name:d.name,email:d.email,role:d.role}}:g.NextResponse.json({success:!1,message:"Permiss\xe3o insuficiente. Requer perfil de Administrador."},{status:403})}},51259:(a,b,c)=>{c.d(b,{b:()=>j});var d=c(40498),e=c(77598);async function f(a){let b=await (0,d.L)(),c=b.prepare("SELECT * FROM ai_routes WHERE task_name = ? AND is_active = 1").get(a),e=[],f=(a,c)=>{if(!a||!c)return;let d=b.prepare("SELECT name, provider_type, api_key_encrypted, base_url FROM ai_providers WHERE id = ?").get(a),f=b.prepare("SELECT model_id FROM ai_models WHERE id = ?").get(c);if(d&&f){let a=d.api_key_encrypted;a||("gemini"===d.provider_type?a=process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY:"openai"===d.provider_type?a=process.env.OPENAI_API_KEY:"anthropic"===d.provider_type?a=process.env.ANTHROPIC_API_KEY:"groq"===d.provider_type?a=process.env.GROQ_API_KEY:"openrouter"===d.provider_type&&(a=process.env.OPENROUTER_API_KEY)),e.push({providerName:d.name,providerType:d.provider_type,modelId:f.model_id,apiKey:a,baseUrl:d.base_url})}};return c&&(f(c.primary_provider_id,c.primary_model_id),f(c.fallback1_provider_id,c.fallback1_model_id),f(c.fallback2_provider_id,c.fallback2_model_id)),0===e.length&&e.push({providerName:"Google Gemini",providerType:"gemini",modelId:"gemini-2.5-flash",apiKey:process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY,baseUrl:"https://generativelanguage.googleapis.com/v1beta"}),e}async function g(a,b){if(!a.apiKey)throw Error("Chave de API do Gemini n\xe3o configurada");let c=`${a.baseUrl||"https://generativelanguage.googleapis.com/v1beta"}/models/${a.modelId}:generateContent?key=${a.apiKey}`,d={contents:[{role:"user",parts:[{text:(b.systemPrompt?`${b.systemPrompt}

`:"")+b.prompt}]}],generationConfig:{temperature:b.temperature??.7,maxOutputTokens:b.maxTokens??4096}},e=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)});if(!e.ok){let a=await e.text();throw Error(`Gemini API Error (${e.status}): ${a}`)}let f=await e.json(),g=f.candidates?.[0]?.content?.parts?.[0]?.text||"",h=f.usageMetadata?.promptTokenCount||Math.ceil(b.prompt.length/4),i=f.usageMetadata?.candidatesTokenCount||Math.ceil(g.length/4);return{text:g,tokensPrompt:h,tokensCompletion:i}}async function h(a,b){if(!a.apiKey)throw Error(`Chave de API do provedor ${a.providerName} n\xe3o configurada`);let c="groq"===a.providerType?"https://api.groq.com/openai/v1":"openrouter"===a.providerType?"https://openrouter.ai/api/v1":"https://api.openai.com/v1",d=a.baseUrl&&a.baseUrl.trim()?a.baseUrl.trim():c,e=`${d.replace(/\/+$/,"")}/chat/completions`,f=[];b.systemPrompt&&f.push({role:"system",content:b.systemPrompt}),f.push({role:"user",content:b.prompt});let g={"Content-Type":"application/json",Authorization:`Bearer ${a.apiKey}`};"openrouter"===a.providerType&&(g["HTTP-Referer"]="https://williambdesigner.com.br",g["X-Title"]="William Barbosa Platform");let h=await fetch(e,{method:"POST",headers:g,body:JSON.stringify({model:a.modelId,messages:f,temperature:b.temperature??.7,max_tokens:b.maxTokens??4096})});if(!h.ok){let b=await h.text();throw Error(`${a.providerName} API Error (${h.status}): ${b}`)}let i=await h.json(),j=i.choices?.[0]?.message?.content||"",k=i.usage?.prompt_tokens||Math.ceil(b.prompt.length/4),l=i.usage?.completion_tokens||Math.ceil(j.length/4);return{text:j,tokensPrompt:k,tokensCompletion:l}}async function i(a,b){if(!a.apiKey)throw Error("Chave de API da Anthropic n\xe3o configurada");let c=`${a.baseUrl||"https://api.anthropic.com/v1"}/messages`,d=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":a.apiKey,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:a.modelId,system:b.systemPrompt||void 0,messages:[{role:"user",content:b.prompt}],max_tokens:b.maxTokens??4096,temperature:b.temperature??.7})});if(!d.ok){let a=await d.text();throw Error(`Anthropic API Error (${d.status}): ${a}`)}let e=await d.json(),f=e.content?.[0]?.text||"",g=e.usage?.input_tokens||Math.ceil(b.prompt.length/4),h=e.usage?.output_tokens||Math.ceil(f.length/4);return{text:f,tokensPrompt:g,tokensCompletion:h}}async function j(a){let b=Date.now(),c=await f(a.task),j=await (0,d.L)(),k=null,l=!1;for(let d=0;d<c.length;d++){let f=c[d];d>0&&(l=!0);try{let c;c="gemini"===f.providerType?await g(f,a):"anthropic"===f.providerType?await i(f,a):await h(f,a);let d=Date.now()-b;return j.prepare(`
        INSERT INTO ai_logs (id, task_name, provider_used, model_used, tokens_prompt, tokens_completion, duration_ms, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run((0,e.randomUUID)(),a.task,f.providerName,f.modelId,c.tokensPrompt,c.tokensCompletion,d,l?"FALLBACK":"SUCCESS",new Date().toISOString()),{text:c.text,provider:f.providerName,model:f.modelId,tokensPrompt:c.tokensPrompt,tokensCompletion:c.tokensCompletion,durationMs:d,usedFallback:l}}catch(a){k=a,console.warn(`[AI Router] Falha no provedor ${f.providerName} (${f.modelId}):`,a.message)}}console.log("[AI Router] Provedores externos indispon\xedveis ou sem chaves. Executando gerador estrat\xe9gico inteligente local.");let m=function(a){if("BLOG_WRITING"===a.task||"BLOG_IDEATION"===a.task){a.context?.theme,a.context?.audience;let b=a.context?.keyword||"Intelig\xeancia Artificial para Empresas",c=`
# Como Alavancar sua Empresa com Intelig\xeancia Artificial e Alta Performance Digital

A evolu\xe7\xe3o tecnol\xf3gica recente deixou de ser um diferencial de grandes corpora\xe7\xf5es de tecnologia e tornou-se um pr\xe9-requisito de sobreviv\xeancia e escala para qualquer modelo de neg\xf3cio moderno. Em um mercado onde a agilidade e o posicionamento ditam o ritmo, aplicar **${b}** e arquitetura digital refinada \xe9 a chave mestra para superar concorrentes e encantar clientes.

---

## O Novo Padr\xe3o de Efici\xeancia Operacional

Historicamente, empresas investiam centenas de horas humanas em tarefas repetitivas: triagem manual de contatos, respostas lentas em canais de atendimento, reconcilia\xe7\xe3o de dados dispersos e p\xe1ginas na web que agiam apenas como "cart\xf5es de visita mortos".

Hoje, uma presen\xe7a digital estrat\xe9gica combinada com intelig\xeancia artificial inverte essa equa\xe7\xe3o:
- **Atendimento Consultivo 24/7**: Agentes aut\xf4nomos treinados com as regras do seu neg\xf3cio realizam a pr\xe9-qualifica\xe7\xe3o imediata de leads.
- **Autoridade Visual & Percep\xe7\xe3o de Valor**: Interfaces com design editorial e alta legibilidade transmitem confian\xe7a instant\xe2nea.
- **Redu\xe7\xe3o Dr\xe1stica de Custos**: Menos fric\xe7\xe3o interna e maior convers\xe3o comercial direta.

---

## Os 3 Pilares da Implementa\xe7\xe3o Estrat\xe9gica

### 1. Diagn\xf3stico Claro dos Gargalos Reais
Antes de adotar qualquer ferramenta, o primeiro passo indispens\xe1vel \xe9 entender exatamente onde a empresa perde tempo e oportunidades. A tecnologia deve servir ao objetivo comercial, n\xe3o o contr\xe1rio.

### 2. Design e Arquitetura Focados em Convers\xe3o
N\xe3o basta ter um site; \xe9 indispens\xe1vel ter uma estrutura pensada nos m\xednimos detalhes: carregamento ultra-r\xe1pido, hierarquia tipogr\xe1fica impec\xe1vel, pontos de contato evidentes e copy envolvente.

### 3. Agentes de IA Especializados
Ao inv\xe9s de chatbots gen\xe9ricos e engessados, sistemas modernos utilizam roteadores inteligentes de modelos com racioc\xednio contextual para dialogar com maturidade e profundidade com seu cliente.

---

## Conclus\xe3o e Pr\xf3ximos Passos

A moderniza\xe7\xe3o do seu neg\xf3cio n\xe3o precisa ser traum\xe1tica ou arrastada por meses. Com o acompanhamento de quem domina design estrat\xe9gico e engenharia de intelig\xeancia artificial, voc\xea pode colocar sua opera\xe7\xe3o no patamar das marcas mais admiradas do seu segmento.

> **Quer descobrir exatamente como aplicar essas solu\xe7\xf5es na realidade da sua empresa?**
> Conhe\xe7a nosso diagn\xf3stico estrat\xe9gico interativo ou fale diretamente com nossa equipe.
    `.trim();return{text:c,tokensPrompt:Math.ceil(a.prompt.length/4),tokensCompletion:Math.ceil(c.length/4)}}return{text:`An\xe1lise estrat\xe9gica gerada pelo AI Router para a tarefa ${a.task}. O sistema processou as instru\xe7\xf5es com sucesso.`,tokensPrompt:50,tokensCompletion:80}}(a),n=Date.now()-b;return j.prepare(`
    INSERT INTO ai_logs (id, task_name, provider_used, model_used, tokens_prompt, tokens_completion, duration_ms, status, error_message, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'FALLBACK', ?, ?)
  `).run((0,e.randomUUID)(),a.task,"AI Engine Local","strategic-offline-generator",m.tokensPrompt,m.tokensCompletion,n,k?k.message:"Chaves externas n\xe3o configuradas - fallback aut\xf4nomo executado",new Date().toISOString()),{text:m.text,provider:"AI Engine Integrada",model:"gerador-estrategico-v1",tokensPrompt:m.tokensPrompt,tokensCompletion:m.tokensCompletion,durationMs:n,usedFallback:!0}}},92280:(a,b,c)=>{Object.defineProperty(b,"I",{enumerable:!0,get:function(){return g}});let d=c(28208),e=c(47617),f=c(62018);async function g(a,b,c,g){if((0,d.isNodeNextResponse)(b)){var h;b.statusCode=c.status,b.statusMessage=c.statusText;let d=["set-cookie","www-authenticate","proxy-authenticate","vary"];null==(h=c.headers)||h.forEach((a,c)=>{if("x-middleware-set-cookie"!==c.toLowerCase())if("set-cookie"===c.toLowerCase())for(let d of(0,f.splitCookiesString)(a))b.appendHeader(c,d);else{let e=void 0!==b.getHeader(c);(d.includes(c.toLowerCase())||!e)&&b.appendHeader(c,a)}});let{originalResponse:i}=b;c.body&&"HEAD"!==a.method?await (0,e.pipeToNodeResponse)(c.body,i,g):i.end()}}}};